# SuperClick
A tool for clicking at speeds up to 180+ clicks/s.
## Usage
In a terminal:
```python3 -m superclick```
Super/Cmd is the default hotkey
- Hold Hot+C to left-click
- Hold Hot+V to right-click
- Press Hot+Q to quit
