# SuperClick
A tool for clicking at insane speeds.
## Usage
In a terminal:
```python3 -m superclick```
- Hold S+C to click
- Press S+Q to quit
